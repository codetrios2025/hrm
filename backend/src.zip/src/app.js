import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import routes from "./routes/index.js";
import { errorHandler } from "./middlewares/error.middleware.js";
import { ApiError } from "./utils/ApiError.js";
import { ENV } from "./config/env.js";

const app = express();

// Security Headers
app.use(helmet());

// CORS Protection
app.use(
  cors({
    origin: ENV.CORS_ORIGIN,
    credentials: true,
  }),
);

// Global Rate Limiter: max 200 requests per 15 mins
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message:
    "Too many requests created from this IP, please try again after 15 minutes",
});
app.use("/api", limiter);

// Body Parsers
app.use(express.json({ limit: "10mb" })); // Mitigate large payload DoS
app.use(express.urlencoded({ extended: true, limit: "10kb" }));

// API Endpoints
app.use("/api", routes);

// 404 Handler
app.use((req, res, next) => {
  next(new ApiError(404, `Route ${req.originalUrl} not found on this server`));
});

// Centralized Error Middleware
app.use(errorHandler);

export default app;

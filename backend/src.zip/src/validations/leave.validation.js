import Joi from "joi";

export const applyLeaveSchema = Joi.object({
  leaveType: Joi.string().valid("casual", "sick", "paid", "oh").required(),
  startDate: Joi.date().iso().required(),
  endDate: Joi.date().iso().min(Joi.ref("startDate")).required(),
  reason: Joi.string().trim().min(3).max(500).required(),
});

export const reviewLeaveSchema = Joi.object({
  status: Joi.string()
    .valid("pending", "approved", "rejected", "cancelled")
    .required(),
  rejectionReason: Joi.string().trim().max(250).allow("", null).optional(),
});
